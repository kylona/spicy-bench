So you want to run graphing verification?

1. properties.jpf in this directory must be modified to point at the file paths on your system.
2. Compiled classfiles (with directory structure intact) must be placed into the input_classes folder.
3. navigate to graph/build
4. Run the RunJPF.jar file passing the paramater of the properties file.

(in windows this is java -jar RunJPF.jar ../../properties.jpf , might be something else on your system).
(you can also change the location of the generated classfile.)